package com.work.assignments;

public interface Player {

   
    void gameStartup();

    
    void drawCard();

  
    boolean wantToStay();

    int getTotal();
}