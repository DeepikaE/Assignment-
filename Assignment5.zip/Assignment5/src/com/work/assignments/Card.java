package com.work.assignments;

import java.util.Random;

public class Card {
    private final int cardValue;

    Card(){
        cardValue = getRandomCardNumber();
    }

    public int getValue(){
        return cardValue;
    }

    
    private int getRandomCardNumber(){
    	int randomCardVal=0 ;
        int minCardVal = 2;
        int maxCardVal = 11;
        int range = (maxCardVal - minCardVal);

        randomCardVal = new Random().nextInt(range + 1) + minCardVal;

        return randomCardVal;
    }
}	