package com.work.assignments;

import java.util.Arrays;

public class Dealer implements Player {

    private final String dealer = "Dealer";

    Card[] dealerCards = new Card[0];

    
    Dealer(){
        dealerCards = Arrays.copyOf(dealerCards, dealerCards.length + 2);
        dealerCards[0] = new Card();
        dealerCards[1] = new Card();

       System.out.println("The dealer has a " + dealerCards[0].getValue() + " showing, and a hidden card.");
    }

    
    @Override
    public void gameStartup(){
        System.out.println("Dealer's turn!\n");

        int total = getTotal();
        System.out.println("hidden card was a " + dealerCards[1].getValue() + "\n" +
                            " total was " + total + ".\n");
    }

    
    @Override
    public void drawCard() {
        dealerCards = Arrays.copyOf(dealerCards, dealerCards.length + 1);
        dealerCards[dealerCards.length - 1] = new Card();

        int lastCard = dealerCards.length - 1;
        System.out.println("Dealer drew a " + dealerCards[lastCard].getValue());
    }

   
   
    @Override
    public boolean wantToStay() {
        boolean stay = false;
        int total = getTotal();

        if(total > 16){
            stay = true;
            System.out.println("Dealer stays.\n");
        }
        else{
            System.out.println("Dealer hits.");
        }
        return stay;
    }

    
    @Override
    public int getTotal() {
        int totalValue = 0;

        for (Card c : dealerCards) {
            int cardValue = c.getValue();
            totalValue = totalValue + cardValue;
        }

        return totalValue;
    }

    
    @Override
    public String toString(){
        return dealer;
    } 
}

