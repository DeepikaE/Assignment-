package com.work.assignments;

import java.util.Arrays;
import java.util.Scanner;

public class User implements Player {

    private final String user;

    private Card[] userHand = new Card[0];

   
    User(String name){
        user = name;

        userHand = Arrays.copyOf(userHand, userHand.length + 2);
        userHand[0] = new Card();
        userHand[1] = new Card();

        System.out.println("Player get a " + userHand[0].getValue() + " and a " + userHand[1].getValue() + ".");
        int total = getTotal();
        System.out.println("Player total cards value is: " + total + "\n");
    }

   
    @Override
    public void gameStartup(){
        System.out.println("Player turn!");
    }

   
    @Override
    public int getTotal(){
        int totalValue = 0;

        for (Card c : userHand) {
            int cardValue = c.getValue();
            if(cardValue==11)
            {
            	if(totalValue>=11)
            	{
            		totalValue = totalValue + 1;
            	}else
            	{
            		totalValue = totalValue + cardValue;
            	}
            	
            }else
            {
            	totalValue = totalValue + cardValue;
            }
            
        }

        return totalValue;
    }

   
    @Override
    public void drawCard() {
        userHand = Arrays.copyOf(userHand, userHand.length + 1);
        userHand[userHand.length - 1] = new Card();

        int lastCard = userHand.length - 1;
        System.out.println("Player drew a " + userHand[lastCard].getValue());
    }

    
    @Override
    public boolean wantToStay() {
        Boolean stay = null;

        while(stay == null){
            Scanner sc = new Scanner(System.in);
            
            if(getTotal()==21)
            {
            	return false;
            }
            System.out.print("Would you like to \"hit\" or \"stay\"? ");
            String input = sc.nextLine();

            String hitOrStay = input.toLowerCase();

            switch(hitOrStay){
                case "hit":
                    stay = false;
                    break;
                case "stay":
                    stay = true;
                    break;
                default:
                    System.out.println("That is not a valid option.");
                    break;
            }
        }
        return stay;
    }

    
    @Override
    public String toString(){
        return user;
    }
}

